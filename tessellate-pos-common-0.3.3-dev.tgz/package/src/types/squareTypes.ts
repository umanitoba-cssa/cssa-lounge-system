export interface squareItemVariation {
    itemId?: string | null;
    name?: string | null;
    sku?: string | null;
    upc?: string | null;
    ordinal?: string | null;
    pricingType?: "FIXED_PRICING" | "VARIABLE_PRICING";
    priceMoney?: squareMoney;
    locationOverrides?: squareItemVariationLocationOverrides[] | null;
    trackInventory?: boolean | null;
    parent?: itemSummary | null;
}

export interface squareMoney {
    amount?: bigint;
    currency?: string;
}

export interface itemSummary {
    id: string;
    name?: string | null;
}

export interface squareHelperItemVariation {
    itemVariationData: squareItemVariation;
    id: string;
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
}

export interface squareItemVariationLocationOverrides {
    locationId?: string | null;
    priceMoney?: {
        amount: bigint;
        currency: string;
    };
    pricingType?: "FIXED_PRICING" | "VARIABLE_PRICING";
    trackInventory?: boolean | null;
}

export interface squareItemCategory {
    id?: string;
    name?: string | null;
    parentCategory?: squareItemCategory | null;
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
    imageId?: string | null;
    imageURL?: string | null;
}

/**
 * DO NOT USE THIS, use squareItemCategory instead.
 * INTERNAL USE ONLY FOR COMPATIBILITY WITH SQUARE API TYPES
 */
export interface squareHelperCategory {
    id: string;
    ordinal?: bigint | null;
}

export interface squareItem {
    id: string;
    name?: string | null | undefined;
    buyerFacingName?: string | null;
    labelColor?: string | null;
    isTaxable?: boolean | null;
    variations: squareItemVariation[] | null;
    categories?: squareItemCategory[];
    isArchived?: boolean | null;
    reportingCategoryIds?: squareItemCategory[];
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
    imageIds?: string[] | null;
    imageURLs?: string[] | null;
}

export interface squareCartItem extends squareItemVariation {
    imageURL?: string | null;
    quantity?: bigint;
    parent?: itemSummary | null;
}

export interface squareItemCatalog {
    items: squareItem[];
}

export interface squareDiscount {
    id: string;
    name?: string | null;
    discountType?:
        | "FIXED_AMOUNT"
        | "FIXED_PERCENTAGE"
        | "VARIABLE_AMOUNT"
        | "VARIABLE_PERCENTAGE";
    amountMoney?: {
        amount: bigint;
        currency: string;
    };
    percentage?: string | null;
    pinRequired?: boolean | null;
    labelColor?: string | null;
    modifyTaxBasis?: "MODIFY_TAX_BASIS" | "DO_NOT_MODIFY_TAX_BASIS";
    maximumAmountMoney?: {
        amount: bigint;
        currency: string;
    };
}

export interface squareOrder {
    id?: string;
    locationId: string;
    referenceId?: string | null;
    source?: {
        name?: string | null;
    };
    customerId?: string | null;
    lineItems?: squareCartItem[] | null;
    taxes?: null;
    discounts: squareDiscount[];
    netAmount?: {
        totalMoney?: squareMoney;
        taxMoney?: squareMoney;
        discountMoney?: squareMoney;
        tipMoney?: squareMoney;
        serviceChargeMoney?: squareMoney;
    };
    roundingAdjustment?: squareMoney;
    tenders?: squareTender[];
    createdAt?: string;
    updatedAt?: string;
    closedAt?: string;
    state?: "OPEN" | "COMPLETED" | "CANCELED" | "DRAFT";
    version?: number;
    totalMoney?: squareMoney;
    totalTaxMoney?: squareMoney;
    totalDiscountMoney?: squareMoney;
    totalTipMoney?: squareMoney;
    totalServiceChargeMoney?: squareMoney;
}
export interface squareTender {
    id: string;
    locationId: string;
    transactionId: string;
    createdAt?: string;
    amountMoney?: squareMoney;
    tipMoney?: squareMoney;
    processingFeeMoney?: squareMoney;
    customerId?: string | null;
    type:
        | "CARD"
        | "CASH"
        | "THIRD_PARTY_CARD"
        | "SQUARE_GIFT_CARD"
        | "NO_SALE"
        | "SQUARE_ACCOUNT"
        | "OTHER";
    cardDetails?: {
        status: "AUTHORIZED" | "CAPTURED" | "VOIDED" | "FAILED";
        card: {
            cardBrand:
                | "VISA"
                | "MASTERCARD"
                | "AMERICAN_EXPRESS"
                | "INTERAC"
                | "DISCOVER"
                | "JCB"
                | "CHINA_UNIONPAY"
                | "OTHER_BRAND";
            last4: string;
            expMonth: number;
            expYear: number;
        };
        entryMethod: "KEYED" | "SWIPED" | "EMV" | "CONTACTLESS" | "ON_FILE";
    };
    cashDetails?: {
        buyerTenderedMoney?: squareMoney;
        changeBackMoney?: squareMoney;
    };
    squareAccountDetails?: {
        status: "AUTHORIZED" | "CAPTURED" | "VOIDED" | "FAILED";
    };
    paymentId?: string | null;
}
