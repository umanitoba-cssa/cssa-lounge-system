export interface squareItemVariation {
    itemId?: string | null;
    name?: string | null;
    sku?: string | null;
    upc?: string | null;
    ordinal?: string | null;
    pricingType?: "FIXED_PRICING" | "VARIABLE_PRICING";
    priceMoney?: {
        amount: bigint;
        currency: string;
    };
    locationOverrides?: squareItemVariationLocationOverrides[] | null;
    trackInventory?: boolean | null;
    parent?: itemSummary | null;
}

export interface itemSummary {
    id: string;
    name?: string | null;
}

export interface squareHelperItemVariation {
    itemVariationData: squareItemVariation;
    id: string;
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
}

export interface squareItemVariationLocationOverrides {
    locationId?: string | null;
    priceMoney?: {
        amount: bigint;
        currency: string;
    };
    pricingType?: "FIXED_PRICING" | "VARIABLE_PRICING";
    trackInventory?: boolean | null;
}

export interface squareItemCategory {
    id?: string;
    name?: string | null;
    parentCategory?: squareItemCategory | null;
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
    imageId?: string | null;
    imageURL?: string | null;
}

/**
 * DO NOT USE THIS, use squareItemCategory instead.
 * INTERNAL USE ONLY FOR COMPATIBILITY WITH SQUARE API TYPES
 */
export interface squareHelperCategory {
    id: string;
    ordinal?: bigint | null;
}

export interface squareItem {
    id: string;
    name?: string | null | undefined;
    buyerFacingName?: string | null;
    labelColor?: string | null;
    isTaxable?: boolean | null;
    variations: squareItemVariation[] | null;
    categories?: squareItemCategory[];
    isArchived?: boolean | null;
    reportingCategoryIds?: squareItemCategory[];
    presentAtAllLocations?: boolean | null;
    presentAtLocationsIds?: string[];
    imageIds?: string[] | null;
    imageURLs?: string[] | null;
}

export interface squareCartItem extends squareItemVariation {
    imageURL?: string | null;
    quantity?: bigint;
    parent?: itemSummary | null;
}

export interface squareItemCatalog {
    items: squareItem[];
}

export interface squareDiscount {
    id: string;
    name?: string | null;
    discountType?:
        | "FIXED_AMOUNT"
        | "FIXED_PERCENTAGE"
        | "VARIABLE_AMOUNT"
        | "VARIABLE_PERCENTAGE";
    amountMoney?: {
        amount: bigint;
        currency: string;
    };
    percentage?: string | null;
    pinRequired?: boolean | null;
    labelColor?: string | null;
    modifyTaxBasis?: "MODIFY_TAX_BASIS" | "DO_NOT_MODIFY_TAX_BASIS";
    maximumAmountMoney?: {
        amount: bigint;
        currency: string;
    };
}
