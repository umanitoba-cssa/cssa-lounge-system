import type {
    squareCartItem,
    squareItem,
    squareItemVariation,
} from "./squareTypes";

export type cartItem = squareCartItem;

export type item = squareItem;

export type itemVariation = squareItemVariation;
